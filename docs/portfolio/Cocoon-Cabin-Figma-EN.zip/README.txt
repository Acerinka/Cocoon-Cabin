Cocoon Cabin / English portfolio

Nine 2560 x 1440 SVG pages. Each embeds its 3840 x 2160 PNG background.
Titles, copy and labels remain native editable text. Use Inter Regular and SemiBold.
Drag a page into Figma. Keep the background at 2560 x 1440; it already contains the 4K image.
Original screenshots and research evidence inside the bitmap remain raster.
Fonts are not bundled. Inter: https://rsms.me/inter/
No Figma import was performed during this export.
