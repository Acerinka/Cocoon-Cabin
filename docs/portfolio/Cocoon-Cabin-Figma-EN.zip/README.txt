Cocoon Cabin / English portfolio

Nine 2560 x 1440 SVG pages translated from the user-revised case study.
Each embeds the original 3840 x 2160 PNG background.
243 native editable text objects; use Inter Regular and SemiBold.
The cover includes GitHub, English film and Chinese film links.
PDF links are clickable. SVG anchors work in supporting viewers; Figma import may not retain hyperlinks.
Drag a page into Figma. Keep the 2K canvas; no separate background placement is needed.
Original evidence screenshots inside the background remain raster. Fonts are not bundled.
Inter: https://rsms.me/inter/
No Figma import was performed during this export.
